package OEPpackage;
import static org.junit.Assert.assertEquals;

import java.sql.SQLException;

import org.junit.Test;
	
public class UnitTesting 
{
	@Test
	public void testA() throws Exception
	{
		AdminBean cb=new AdminBean();
		cb.setFirstName("hi");
		cb.setLastName("hi");
		cb.setAge(1);
		cb.setGender("kl");
		cb.setContactNumber(Long.parseLong("188093"));
		cb.setPassword("kl");
		cb.setREEnterPassword("kl");
		cb.setEmail("kl");
		cb.setAssociateID("kl");
		assertEquals(1,AdminDAO.SaveAdmin(cb));
	}
}