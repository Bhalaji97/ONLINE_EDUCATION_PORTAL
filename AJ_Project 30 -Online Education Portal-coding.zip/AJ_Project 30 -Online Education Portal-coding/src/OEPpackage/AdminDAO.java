package OEPpackage;


import java.sql.*;


public class AdminDAO 
{
   

public static Connection getConnect()
   {
	   try
	   {
		  Class.forName("com.mysql.jdbc.Driver");
		   Connection con=  DriverManager.getConnection("jdbc:mysql://localhost:3306/adminlogin","root","root");
		   return con;
	   }catch(Exception e)
	   {
		   System.out.println(e);
	 return null; }

   }
public static int SaveAdmin(AdminBean ab)throws SQLException
{
	Connection con=getConnect();
	PreparedStatement ps=con.prepareStatement("insert into signup values(?,?,?,?,?,?,?,?,?)");
	ps.setString(1,ab.getFirstName());
	ps.setString(2,ab.getLastName());
	ps.setInt(3,ab.getAge());
	ps.setString(4,ab.getGender());
	ps.setLong(5,ab.getContactNumber());
	ps.setString(6,ab.getPassword());
	ps.setString(7,ab.getREEnterPassword());
	ps.setString(8,ab.getEmail());
	ps.setString(9,ab.getAssociateID());
	int k=ps.executeUpdate();
	return k;
}

public static int checkLogin(String aid, String password) throws SQLException
{
	int k=0;
	Connection con=getConnect();
	PreparedStatement ps=con.prepareStatement("select AssociateID, password from signup");
	ResultSet rs=ps.executeQuery();
	while(rs.next())
	{
		String aid1=rs.getString("AssociateID");
		String pwd=rs.getString("Password");
		if(aid1.equals(aid)  && pwd.equals(password))
		{
		k=1;
		break;
		}
		else
		{
			k=0;
		}
		//return k;
		
	}
	return k;
	
}



//public static List<AdminBean> getAdminInfo()
/*{
	
}*/
}
