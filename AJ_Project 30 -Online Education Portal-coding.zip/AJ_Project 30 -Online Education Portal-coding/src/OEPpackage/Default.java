package OEPpackage;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import OEPpackage.AdminBean;
import OEPpackage.AdminDAO;

/**
 * Servlet implementation class Default
 */
@WebServlet("/Default")
public class Default extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Default() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String FirstName=request.getParameter("First_Name");
		String LastName=request.getParameter("Last_Name");
		int Age=Integer.parseInt(request.getParameter("age"));
		String Gender=request.getParameter("gender");
		Long ContactNumber=Long.parseLong(request.getParameter("cnu"));
		String Password=request.getParameter("psw");
		String REEnterPassword=request.getParameter("rpsw");
		String Email=request.getParameter("email");
		String AssociateID=request.getParameter("aid");
		AdminBean a1=new AdminBean();
		a1.setFirstName(FirstName);
		a1.setLastName(LastName);
		a1.setAge(Age);
		a1.setGender(Gender);
		a1.setContactNumber(ContactNumber);
		a1.setPassword(Password);
		a1.setEmail(Email);
		a1.setAssociateID(AssociateID);
		a1.setREEnterPassword(REEnterPassword);
		try {
			if(Password.equals(REEnterPassword))
			{
			int c=AdminDAO.SaveAdmin(a1);
			
			if(c>0)
			{
				out.println("<script>alert('Congratulation you have sucessfully registered with our system')</script>");
				HttpSession session=request.getSession();				
				session.setAttribute("key1",AssociateID );
				session.setAttribute("key2",Password);
				request.getRequestDispatcher("Login.html").include(request, response);
				
				
				
			}
			else
			{
				
			}
			} else
			{
				out.println("<script>alert('Mismatch Password')</script>");
				request.getRequestDispatcher("AdminLogin.html").include(request, response);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
