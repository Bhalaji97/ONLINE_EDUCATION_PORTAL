package OEPpackage;

public class AdminBean 
{
String FirstName;
String LastName;
int Age;
String Gender;
Long ContactNumber;
String Password;
String REEnterPassword;
String Email;
String AssociateID;
public String getFirstName()
{
	return FirstName;
}
public String getLastName()
{
	return LastName;
}
public int getAge()
{
	return Age;
}
public String getGender()
{
	return Gender;
}
public Long getContactNumber()
{
	return ContactNumber;
}
public String getPassword()
{
	return Password;
}
public String getREEnterPassword()
{
	return REEnterPassword;
}
public String getEmail()
{
	return Email;
}
public String getAssociateID()
{
	return AssociateID;
}
public void setFirstName(String FirstName)
{
	this.FirstName=FirstName;
}
public void setLastName(String LastName)
{
	this.LastName=LastName;
}
public void setAge(int Age)
{
	this.Age=Age;
}
public void setGender(String Gender)
{
	this.Gender=Gender;
}
public void setContactNumber(Long ContactNumber)
{
	this.ContactNumber=ContactNumber;
}
public void setPassword(String Password)
{
	this.Password=Password;
}
public void setREEnterPassword(String REEnterPassword)
{
	this.REEnterPassword=REEnterPassword;
}
public void setEmail(String Email)
{
	this.Email=Email;
}
public void setAssociateID(String AssociateID)
{
	this.AssociateID=AssociateID;
}
}
