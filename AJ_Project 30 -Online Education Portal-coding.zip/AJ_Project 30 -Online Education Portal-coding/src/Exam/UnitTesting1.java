package Exam;
import static org.junit.Assert.assertEquals;

import java.sql.SQLException;

import org.junit.Test;


public class UnitTesting1 
{
	@Test
	public void testA() throws Exception
	{
		ExamClass cb=new ExamClass();
		cb.setName("hi");
		cb.setSemester(1);
		cb.setStartDate("hi");
		cb.setEndDate("hi");
		assertEquals(1,ExamBackend.SaveExamDetails(cb));
	}
}
