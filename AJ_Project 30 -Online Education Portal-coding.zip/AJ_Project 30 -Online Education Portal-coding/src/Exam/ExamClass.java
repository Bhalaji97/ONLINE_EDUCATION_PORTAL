package Exam;
public class ExamClass {
 String course_Name;
 int semester;
 String startDate;
 String endDate;
 public void setName(String course_Name)
 {
	 this.course_Name=course_Name;
 }
 public void setSemester(int semester)
 {
	 this.semester=semester;
 }
 public void setStartDate(String startDate)
 {
	 this.startDate=startDate;
 }
 public void setEndDate(String endDate)
 {
	 this.endDate=endDate;
 }
 public String getName()
 {
	 return course_Name;
 }
 public int getSemester()
 {
	 return semester;
 }
 public String getStartDate()
 {
	 return startDate;
 }
 public String getEndDate()
 {
	 return endDate;
 }
}

