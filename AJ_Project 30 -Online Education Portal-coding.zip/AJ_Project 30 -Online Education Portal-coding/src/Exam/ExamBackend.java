package Exam;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

public class ExamBackend {

	
	public static Connection getConnect()
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/adminlogin","root" ,"root");
			return con;
		}
		catch(Exception e)
		{
			System.out.println(e);
			return null;
		}
	}
	
	public static int SaveExamDetails(ExamClass ecc) throws SQLException
	{
		Connection con=getConnect();
		PreparedStatement ps= (PreparedStatement) con.prepareStatement("insert into exam values(?,?,?,?)");
		ps.setString(1, ecc.getName());
		ps.setInt(2, ecc.getSemester());
		ps.setString(3,ecc.getStartDate());
		ps.setString(4,ecc.getEndDate());
		int k=ps.executeUpdate();
		return k;
	}
	public static List<ExamClass> getAllExam() throws SQLException
	{
		List<ExamClass> list=new ArrayList<>();
		
		Connection con=getConnect();
		PreparedStatement ps= (PreparedStatement) con.prepareStatement("select * from exam ");
		
		ResultSet rs=ps.executeQuery();
		while(rs.next())
		{
			ExamClass ec=new ExamClass();
			ec.setName(rs.getString(1));
			ec.setSemester(rs.getInt(2));
			ec.setStartDate(rs.getString(3));
			ec.setEndDate(rs.getString(4));
			list.add(ec);
			
			
			
		}
		
		return list;
		
	}
	public static int updateExam(String name, int sem, String sdate, String edate) throws SQLException
	{
		Connection con=getConnect();
		PreparedStatement ps=(PreparedStatement) con.prepareStatement("update exam set  semester=?, StartDate=?, EndDate=? where cname=?");
		ps.setInt(1, sem);
		ps.setString(2, sdate);
		ps.setString(3, edate);
		ps.setString(4, name);
		int k=ps.executeUpdate();
		return k;
		
		
	}
	
	
	
	public static int deleteExam(String name) throws SQLException
	{
		Connection con=getConnect();
		PreparedStatement ps=(PreparedStatement) con.prepareStatement("delete from exam where cname=? ");
		ps.setString(1, name);
	
		int k=ps.executeUpdate();
		return k;
	}

	
	
}
