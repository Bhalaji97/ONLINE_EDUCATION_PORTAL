package Studentpackage;

public class StudentBean
{
	String studentid;
	String studentname;
	String courseid;
	String streamname;
	String registrationdate;
	String modeofpayment;
	public String getStudentID()
	{
	       return studentid;
	}
	public String getStudentName()
	{
	       return studentname;
	}
	public String getCourseID()
	{
	       return courseid;
	}
	public String getStreamName()
	{
	       return streamname;
	}
	public String getRegistrationDate()
	{
	       return registrationdate;
	}
	public String getModeofPayment()
	{
	       return modeofpayment;
	}


	public void setStudentID(String studentid)
	{
	       this.studentid=studentid;
	}
	public void setStudentName(String studentname)
	{
	       this.studentname=studentname;
	}
	public void setCourseID(String courseid)
	{
	       this.courseid=courseid;
	}
	public void setStreamName(String streamname)
	{
	       this.streamname=streamname;
	}
	public void setRegistrationDate(String registrationdate)
	{
	       this.registrationdate=registrationdate;
	}
	public void setModeofPayment(String modeofpayment)
	{
	       this.modeofpayment=modeofpayment;
	}

}
