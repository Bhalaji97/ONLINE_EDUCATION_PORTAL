package Studentpackage;
import static org.junit.Assert.assertEquals;

import java.sql.SQLException;

import org.junit.Test;
public class UnitTesting 
{
	@Test
	public void testA() throws Exception
	{
		StudentBean cb=new StudentBean();
		cb.setStudentID("hi");
		cb.setStudentName("hi");
		cb.setCourseID("kl");
		cb.setStreamName("kl");
		cb.setRegistrationDate("kl");
		cb.setModeofPayment("kl");
		assertEquals(1,StudentDAO.SaveStudent(cb));
	}
}