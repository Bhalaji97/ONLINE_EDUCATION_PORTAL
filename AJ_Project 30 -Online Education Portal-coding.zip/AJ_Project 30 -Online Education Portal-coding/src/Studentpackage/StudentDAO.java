package Studentpackage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;



public class StudentDAO 
{
	public static Connection getConnect()
	   {
		   try
		   {
			  Class.forName("com.mysql.jdbc.Driver");
			   Connection con= (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/adminlogin","root","root");
			   return con;
		   }catch(Exception e)
		   {
			   System.out.println(e);
		 return null; }

	   }
	public static int SaveStudent(StudentBean sb)throws SQLException
	{
		Connection con=getConnect();
		PreparedStatement ps=con.prepareStatement("insert into student values(?,?,?,?,?,?)");
		ps.setString(1,sb.getStudentID());
		ps.setString(2,sb.getStudentName());
		ps.setString(3,sb.getCourseID());
		ps.setString(4,sb.getStreamName());
		ps.setString(5,sb.getRegistrationDate());
		ps.setString(6,sb.getModeofPayment());
		int k=ps.executeUpdate();
		return k;
	}
	public static List<StudentBean> getAllStudent() throws SQLException
	{
		List<StudentBean> list=new ArrayList<>();
		
		Connection con=getConnect();
		PreparedStatement ps=con.prepareStatement("select * from student ");
		
		ResultSet rs=ps.executeQuery();
		while(rs.next())
		{
			StudentBean ss=new StudentBean();
			ss.setStudentID(rs.getString("sid"));
			ss.setStudentName(rs.getString(2));
			ss.setCourseID(rs.getString(3));
			ss.setStreamName(rs.getString(4));
			ss.setRegistrationDate(rs.getString(5));
			ss.setModeofPayment(rs.getString(6));
			list.add(ss);
			
			
			
		}
		
		return list;
}
	public static int updateStudent(String id, String name, String cid, String sname,String rdate,String mop) throws SQLException
	{
		Connection con=getConnect();
		PreparedStatement ps=con.prepareStatement("update student set sname=?, cid=?, strname=?, regdate=?, mop=? where sid=?");
		ps.setString(1, name);
		ps.setString(2, cid);
		ps.setString(3, sname);
		ps.setString(4, rdate);
		ps.setString(5, mop);
		ps.setString(6, id);
		int k=ps.executeUpdate();
		return k;
		
		
	}
	
	
	
	public static int deleteStudent(String id) throws SQLException
	{
		Connection con=getConnect();
		PreparedStatement ps=con.prepareStatement("delete from student where sid=? ");
		ps.setString(1, id);
	
		int k=ps.executeUpdate();
		return k;
	}
	
}