package CourseStream;

import static org.junit.Assert.assertEquals;

import java.sql.SQLException;

import org.junit.Test;

public class UnitTesting
{
	@Test
	public void testA() throws Exception
	{
		CourseBean cb=new CourseBean();
		cb.setCoursefees(Long.parseLong("188093"));
		cb.setCourseid("1");
		cb.setCoursename("hi");
		cb.setNoofyears(2);
		assertEquals(1,CourseDAO.SaveCourse(cb));
	}
}
