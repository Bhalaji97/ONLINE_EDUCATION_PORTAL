package CourseStream;
import java.sql.*;


public class StreamDAO 
{
	public static Connection getConnect()
	   {
		   try
		   {
			  Class.forName("com.mysql.jdbc.Driver");
			   Connection con= (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/adminlogin","root","root");
			   return con;
		   }catch(Exception e)
		   {
			   System.out.println(e);
		 return null; 
		 }

	   }
	public static int SaveStream(StreamBean stb)throws SQLException
	{
		Connection con=getConnect();
		PreparedStatement ps=con.prepareStatement("insert into stream values(?,?)");
		ps.setString(1,stb.getCourseid());
		ps.setString(2,stb.getStreamname());
		int k=ps.executeUpdate();
		return k;
	}
	
}
