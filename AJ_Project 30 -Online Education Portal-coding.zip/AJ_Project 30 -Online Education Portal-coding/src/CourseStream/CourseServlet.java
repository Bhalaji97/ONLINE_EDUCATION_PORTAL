package CourseStream;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CourseServlet
 */
@WebServlet("/CourseServlet")
public class CourseServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CourseServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String Courseid=request.getParameter("cid");
		String Coursename=request.getParameter("cname");
		int Noofyears=Integer.parseInt(request.getParameter("noy"));
		Long Coursefees=Long.parseLong(request.getParameter("cfees"));
		CourseBean c1=new CourseBean();
		c1.setCourseid(Courseid);
		c1.setCoursename(Coursename);
		c1.setNoofyears(Noofyears);
		c1.setCoursefees(Coursefees);
		try {
			int c=CourseDAO.SaveCourse(c1);
			if(c>0)
			{
				out.println("<script> alert('Course Created Sucessfully')</script>");
				request.getRequestDispatcher("ViewCourse.jsp").include(request, response);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}*/

}
