package CourseStream;

public class StreamBean 
{
	String Courseid;
	String Streamname;
  public String getCourseid()
  {
	  return Courseid;
  }
  public String getStreamname()
  {
	  return Streamname;
  }
  public void setCourseid(String Courseid)
  {
	  this.Courseid=Courseid;
  }
  public void setStreamname(String Streamname)
  {
	  this.Streamname=Streamname;
  }
}
