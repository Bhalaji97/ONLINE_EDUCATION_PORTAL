
	package CourseStream;


	import java.sql.*;
import java.util.ArrayList;
import java.util.List;


	public class CourseDAO 
	{
	   

	public static Connection getConnect()
	   {
		   try
		   {
			  Class.forName("com.mysql.jdbc.Driver");
			   Connection con= (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/adminlogin","root","root");
			   return con;
		   }catch(Exception e)
		   {
			   System.out.println(e);
		 return null; }

	   }
	public static int SaveCourse(CourseBean cb)throws SQLException
	{
		Connection con=getConnect();
		PreparedStatement ps=con.prepareStatement("insert into course values(?,?,?,?)");
		ps.setString(1,cb.getCourseid());
		ps.setString(2,cb.getCoursename());
		ps.setInt(3,cb.getNoofyears());
		ps.setLong(4,cb.getCoursefees());
		int k=ps.executeUpdate();
		return k;
	}
	public static List<CourseBean> getAllCourse() throws SQLException
	{
		List<CourseBean> list=new ArrayList<>();
		
		Connection con=getConnect();
		PreparedStatement ps=con.prepareStatement("select * from Course ");
		
		ResultSet rs=ps.executeQuery();
		while(rs.next())
		{
			CourseBean cc=new CourseBean();
			cc.setCourseid(rs.getString("cid"));
			cc.setCoursename(rs.getString(2));
			cc.setNoofyears(rs.getInt(3));
			cc.setCoursefees(rs.getLong(4));
			list.add(cc);
			
			
			
		}
		
		return list;
		
	}
	public static int updateCourse(String cname, String cid, int noy, long cfees) throws SQLException
	{
		Connection con=getConnect();
		PreparedStatement ps=con.prepareStatement("update Course set cname=?, noy=?, cfees=? where cid=?");
		ps.setString(1, cname);
		ps.setInt(2, noy);
		ps.setLong(3, cfees);
		ps.setString(4, cid);
		int k=ps.executeUpdate();
		return k;
		
		
	}
	
	
	
	public static int deleteCourse(String id) throws SQLException
	{
		Connection con=getConnect();
		PreparedStatement ps=con.prepareStatement("delete from course where cid=? ");
		ps.setString(1, id);
	
		int k=ps.executeUpdate();
		return k;
	}
	public static List<String> getAllId() throws SQLException
	{
		List<String> list=new ArrayList<>();
		
		Connection con=getConnect();
		PreparedStatement ps=con.prepareStatement("select cid from Course ");
		
		ResultSet rs=ps.executeQuery();
		while(rs.next())
		{
			String id=rs.getString("cid");
			list.add(id);
			
			
			
		}
		
		return list;
		
		
		
	}
}
