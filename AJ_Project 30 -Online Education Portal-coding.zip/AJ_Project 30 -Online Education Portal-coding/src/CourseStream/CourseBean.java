package CourseStream;

public class CourseBean
{
   String Courseid;
   String Coursename;
   int Noofyears;
   long Coursefees;
   public String getCourseid()
   {
   	return Courseid;
   }
   public String getCoursename()
   {
   	return Coursename;
   }
   public int getNoofyears()
   {
   	return Noofyears;
   }
   public Long getCoursefees()
   {
   	return Coursefees;
   }
   public void setCourseid(String Courseid)
   {
   	this.Courseid=Courseid;
   }
   public void setCoursename(String Coursename)
   {
   	this.Coursename=Coursename;
   }
   public void setNoofyears(int Noofyears)
   {
   	this.Noofyears=Noofyears;
   }
   public void setCoursefees(Long Coursefees)
   {
   	this.Coursefees=Coursefees;
   }
}
