package FeesPayment;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



/**
 * Servlet implementation class FeesServlet
 */
@WebServlet("/FeesServlet")
public class FeesServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FeesServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String Studentid=request.getParameter("sid");
		int Balance=Integer.parseInt(request.getParameter("bal"));
		Long Totalfees=Long.parseLong(request.getParameter("tfees"));
		String LastpaymentDate=request.getParameter("lpd");
		int Fine=Integer.parseInt(request.getParameter("fine"));
		Long Amount=Long.parseLong(request.getParameter("amt"));
		FeesBean f1=new FeesBean();
		f1.setStudentid(Studentid);
		f1.setBalance(Balance);
		f1.setTotalfees(Totalfees);
		f1.setLastpaymentDate(LastpaymentDate);
		f1.setFine(Fine);
		f1.setAmount(Amount);
		try {
			int c=FeesDAO.SaveFees(f1);
			if(c>0)
			{
				out.println("<script> alert('Fees Created Sucessfully')</script>");
				request.getRequestDispatcher("ViewFees.jsp").include(request, response);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	//protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	//	doGet(request, response);
	//}

}
