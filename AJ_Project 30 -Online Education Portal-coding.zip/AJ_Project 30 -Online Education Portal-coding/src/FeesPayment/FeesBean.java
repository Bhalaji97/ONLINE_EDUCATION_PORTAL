package FeesPayment;

public class FeesBean 
{
	String Studentid;
	int Balance;
	Long Totalfees;
	String LastpaymentDate;
	int Fine;
	Long Amount;
	public String getStudentid()
	{
		return Studentid;
	}
	public int getBalance()
	{
		return Balance;
	}
	public Long getTotalfees()
	{
		return Totalfees;
	}
	public String getLastpaymentDate()
	{
		return LastpaymentDate;
	}
	public int getFine()
	{
		return Fine;
	}
	public Long getAmount()
	{
		return Amount;
	}
	public void setStudentid(String Studentid)
	{
		this.Studentid=Studentid;
	}
	public void setBalance(int Balance)
	{
		this.Balance=Balance;
	}
	public void setTotalfees(Long Totalfees)
	{
		this.Totalfees=Totalfees;
	}
	public void setLastpaymentDate(String LastpaymentDate)
	{
		this.LastpaymentDate=LastpaymentDate;
	}
	public void setFine(int Fine)
	{
		this.Fine=Fine;
	}
	public void setAmount(Long Amount)
	{
		this.Amount=Amount;
	}
}
