package FeesPayment;
import static org.junit.Assert.assertEquals;

import java.sql.SQLException;

import org.junit.Test;




public class UnitTesting 
{
	@Test
	public void testA() throws Exception
	{
		FeesBean cb=new FeesBean();
		cb.setStudentid("hi");
		cb.setBalance(1);
		cb.setTotalfees(Long.parseLong("188093"));
		cb.setLastpaymentDate("kl");
		cb.setFine(1);
		cb.setAmount(Long.parseLong("188093"));
		assertEquals(1,FeesDAO.SaveFees(cb));
	}
}
