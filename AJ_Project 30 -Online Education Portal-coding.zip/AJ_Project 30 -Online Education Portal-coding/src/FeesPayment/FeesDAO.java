package FeesPayment;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;




public class FeesDAO 
{
	public static Connection getConnect()
	   {
		   try
		   {
			  Class.forName("com.mysql.jdbc.Driver");
			   Connection con= (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/adminlogin","root","root");
			   return con;
		   }catch(Exception e)
		   {
			   System.out.println(e);
		 return null; }

	   }
	public static int SaveFees(FeesBean fb)throws SQLException
	{
		Connection con=getConnect();
		PreparedStatement ps=con.prepareStatement("insert into fees values(?,?,?,?,?,?)");
		ps.setString(1,fb.getStudentid());
		ps.setInt(2,fb.getBalance());
		ps.setLong(3,fb.getTotalfees());
		ps.setString(4,fb.getLastpaymentDate());
		ps.setInt(5,fb.getFine());
		ps.setLong(6,fb.getAmount());
		int k=ps.executeUpdate();
		return k;
	}
	public static List<FeesBean> getAllFees() throws SQLException
	{
		List<FeesBean> list=new ArrayList<>();
		
		Connection con=getConnect();
		PreparedStatement ps=con.prepareStatement("select * from fees ");
		
		ResultSet rs=ps.executeQuery();
		while(rs.next())
		{
			FeesBean fc=new FeesBean();
			fc.setStudentid(rs.getString(1));
			fc.setBalance(rs.getInt(2));
			fc.setTotalfees(rs.getLong(3));
			fc.setLastpaymentDate(rs.getString(4));
			fc.setFine(rs.getInt(5));
			fc.setAmount(rs.getLong(6));
			list.add(fc);
			
			
			
		}
		
		return list;
		
	}
	public static int updateFees(String id, int bal, long tf,String lpd, int fine, long amt) throws SQLException
	{
		Connection con=getConnect();
		PreparedStatement ps=con.prepareStatement("update fees set bal=?, tfees=?, lpd=?, fine=?, tamnt=? where sid=?");
		ps.setInt(1, bal);
		ps.setLong(2,tf );
		ps.setString(3, lpd);
		ps.setInt(4, fine);
		ps.setLong(5,amt);
		ps.setString(6, id);
		int k=ps.executeUpdate();
		return k;
		
		
	}
	
	
	
	public static int DeleteFees(String id) throws SQLException
	{
		Connection con=getConnect();
		PreparedStatement ps=con.prepareStatement("delete from fees where sid=? ");
		ps.setString(1, id);
	
		int k=ps.executeUpdate();
		return k;
	}
}
