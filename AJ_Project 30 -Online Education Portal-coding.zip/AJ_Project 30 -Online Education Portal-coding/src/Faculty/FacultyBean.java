package Faculty;

public class FacultyBean 
{
    String Facultyid;
	String Facultyname;
    String Highestqualification;
    String Email;
	long Number;
	String Address;
	int Experience;
	public String getFacultyid() {
		return Facultyid;
	}
	public void setFacultyid(String Facultyid) {
		this.Facultyid = Facultyid;
	}
	public String getFacultyname() {
		return Facultyname;
	}
	public void setFacultyname(String Facultyname) {
		this.Facultyname = Facultyname;
	}
	public String getHighestqualification() {
		return Highestqualification;
	}
	public void setHighestqualification(String Highestqualification) {
		this.Highestqualification = Highestqualification;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String Email) {
		this.Email = Email;
	}
	public long getNumber() {
		return Number;
	}
	public void setNumber(long Number) {
		this.Number = Number;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String Address) {
		this.Address = Address;
	}
	public int getExperience() {
		return Experience;
	}
	public void setExperience(int experience) {
		Experience = experience;
	}
	
	
	
}

