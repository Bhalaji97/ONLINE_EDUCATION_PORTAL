package Faculty;
import static org.junit.Assert.assertEquals;

import java.sql.SQLException;

import org.junit.Test;


public class UnitTesting 
{
	@Test
	public void testA() throws Exception
	{
		FacultyBean cb=new FacultyBean();
		cb.setFacultyid("hi");
		cb.setFacultyname("kl");
		cb.setHighestqualification("jk");
		cb.setEmail("kl");
		cb.setNumber(Long.parseLong("188093"));
		cb.setExperience(1);
		cb.setAddress("188093");
		assertEquals(1,FacultyDAO.SaveFaculty(cb));
	}
}
