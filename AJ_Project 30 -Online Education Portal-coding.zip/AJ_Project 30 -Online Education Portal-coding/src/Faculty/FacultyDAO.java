package Faculty;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;




public class FacultyDAO 
{
	



	public static Connection getConnect()
	   {
		   try
		   {
			  Class.forName("com.mysql.jdbc.Driver");
			   Connection con= (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/adminlogin","root","root");
			   return con;
		   }catch(Exception e)
		   {
			   System.out.println(e);
		 return null; }

	   }
	public static int SaveFaculty(FacultyBean fcb)throws SQLException
	{
		Connection con=getConnect();
		PreparedStatement ps=con.prepareStatement("insert into faculty values(?,?,?,?,?,?,?)");
		ps.setString(1,fcb.getFacultyid());
		ps.setString(2,fcb.getFacultyname());
		ps.setString(3,fcb.getHighestqualification());
		ps.setString(4,fcb.getEmail());
		ps.setLong(5,fcb.getNumber());
		ps.setString(6,fcb.getAddress());
		ps.setInt(7,fcb.getExperience());
		int k=ps.executeUpdate();
		return k;
	}
	public static List<FacultyBean> getAllFaculty() throws SQLException
	{
		List<FacultyBean> list=new ArrayList<>();
		
		Connection con=getConnect();
		PreparedStatement ps=con.prepareStatement("select * from faculty ");
		
		ResultSet rs=ps.executeQuery();
		while(rs.next())
		{
			FacultyBean cc=new FacultyBean();
			cc.setFacultyid(rs.getString(1));
			cc.setFacultyname(rs.getString(2));
			cc.setHighestqualification(rs.getString(3));
			cc.setEmail(rs.getString(4));
			cc.setNumber(rs.getLong(5));
			cc.setAddress(rs.getString(6));
			cc.setExperience(rs.getInt(7));
			list.add(cc);
			
			
			
		}
		
		return list;
		
	}
	public static int updateFaculty(String fid,String fname, String hq, String email, long num,String add,int exp) throws SQLException
	{
		Connection con=getConnect();
		PreparedStatement ps=con.prepareStatement("update faculty set fname=? , hq=? , email=? , num=? , adr=? , exp=? where fid=?");
		ps.setString(1, fname);
		ps.setString(2, hq);
		ps.setString(3, email);
		ps.setLong(4, num);
		ps.setString(5, add);
		ps.setInt(6, exp);
		ps.setString(7,fid);
		int k=ps.executeUpdate();
		return k;
		
		
	}
	
	
	
	public static int DeleteFaculty(String id) throws SQLException
	{
		Connection con=getConnect();
		PreparedStatement ps=con.prepareStatement("delete from faculty where fid=? ");
		ps.setString(1, id);
	
		int k=ps.executeUpdate();
		return k;
	}
}

